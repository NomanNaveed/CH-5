package com.example.chapter5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class orientation extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orientation);
        Bundle b = getIntent().getExtras();
        LinearLayout temp = findViewById(R.id.orientation);
        if(b!=null){
            if(b.getInt("orientation")==1){
                temp.setOrientation(LinearLayout.VERTICAL);

            }else if(b.getInt("orientation")==0){
                temp.setOrientation(LinearLayout.HORIZONTAL);

            }
        }


    }
}