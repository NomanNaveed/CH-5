package com.example.chapter5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ListView listview = null;
    TextView textView = null;
    Intent intent = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listview = findViewById(R.id.listview1);
        String[] items = {"Linear Layout","RelativeLayout",
                "TableLayout","ScrollView"};
        ArrayAdapter<String> adpt = new ArrayAdapter<String>(this,
                R.layout.list_view,items);
        listview.setAdapter(adpt);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch(i){
                    case 0:{
                        intent = new Intent(getApplicationContext(), linearlayout.class);
                        startActivity(intent);
                        break;
                    }
                    case 1:{
                        startActivity(new Intent(getApplicationContext(),relativelayout.class));
                        break;

                    }
                    case 2:{
                        startActivity(new Intent(getApplicationContext(),tablelayout.class));
                        break;

                    }
                    case 3:{
                        startActivity(new Intent(getApplicationContext(),scrollviewlayout.class));
                        break;

                    }
                    case 4:{

                    }
                }
            }
        });


    }
}