package com.example.chapter5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ll_gravity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ll_gravity);
    }
}